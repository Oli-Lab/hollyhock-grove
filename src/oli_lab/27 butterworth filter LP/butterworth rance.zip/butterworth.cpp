//-----------------------------------------------------------------------------
//@file  
//	filterbutterworth.cpp
//
//@author
//	Martin FLEURENT aka 'martignasse'
//
//@brief 
//	Implementation of the filterbutterworth class.
//
//  Example user module to show how to process audio buffers.
//
//@historic 
//	2015/02/23
//    first release for Hollyhock CPP SDK 6.04.001
//
//@IMPORTANT
//	This file is part of the Usine Hollyhock CPP SDK
//
//  Please, report bugs and patch to Usine forum :
//  http://www.sensomusic.com/wiki2/doku.php?id=hollyhock:bugsreport 
//
// All dependencies are under there own licence.
//
//@LICENCE
// Copyright (C) 2013, 2014, 2015 Sensomusic
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of 
// this software and associated documentation files (the "Software"), 
// to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, 
// and/or sell copies of the Software, and to permit persons to whom the Software 
// is furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all 
//     copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE 
// SOFTWARE.
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// includes
//-----------------------------------------------------------------------------
#include "butterworth.h"
// module constants for browser info and module info
const AnsiCharPtr UserModuleBase::MODULE_NAME = "butterworth1";
const AnsiCharPtr UserModuleBase::MODULE_DESC = "butterworth LP";
const AnsiCharPtr UserModuleBase::MODULE_VERSION = "0.1";
//----------------------------------------------------------------------------
// create, general info and destroy methodes
//----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Create
void CreateModule (void* &pModule, AnsiCharPtr optionalString, LongBool Flag, MasterInfo* pMasterInfo, AnsiCharPtr optionalContent)
{
	pModule = new filterbutterworth();
}

// destroy
void DestroyModule(void* pModule) 
{
	// cast is important to call the good destructor
	delete ((filterbutterworth*)pModule);
}

//-------------------------------------------------------------------------
// module constructors/destructors
//-------------------------------------------------------------------------

// constructor
filterbutterworth::filterbutterworth()
{

}

// destructor
filterbutterworth::~filterbutterworth()
{

}

// browser info
void GetBrowserInfo(ModuleInfo* pModuleInfo)
{
	pModuleInfo->Name = UserModuleBase::MODULE_NAME;
	pModuleInfo->Description = UserModuleBase::MODULE_DESC;
	pModuleInfo->Version = UserModuleBase::MODULE_VERSION;
}

void filterbutterworth::onGetModuleInfo (MasterInfo* pMasterInfo, ModuleInfo* pModuleInfo)
{
	pModuleInfo->Name = MODULE_NAME;
	pModuleInfo->Description = MODULE_DESC;
	pModuleInfo->Version = MODULE_VERSION;
	pModuleInfo->ModuleType         = mtSimple;
	pModuleInfo->BackColor = sdkGetUsineColor(clAudioModuleColor) + 0x102011;
    
	// query for multi-channels
	if (pMasterInfo != nullptr)
    {
	    pModuleInfo->QueryString		= sdkGetAudioQueryTitle();
	    pModuleInfo->QueryListValues	= sdkGetAudioQueryChannelList();
	    pModuleInfo->QueryDefaultIdx	= 1;
    }
}

//-----------------------------------------------------------------------------
// query system and init methodes
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// Get total parameters number of the module
int filterbutterworth::onGetNumberOfParams (int queryIndex)
{
	int result = 0;
    this->queryIndex = queryIndex;
    numOfAudiotInsOuts = sdkGetAudioQueryToNbChannels (queryIndex);

    // we want 1 in 1 out per channels
	result = (numOfAudiotInsOuts * 2) + numOfParamAfterAudiotInOut;

    return result;
}

//-----------------------------------------------------------------------------
// Called after the query popup
void filterbutterworth::onAfterQuery (MasterInfo* pMasterInfo, ModuleInfo* pModuleInfo, int queryIndex)
{
	//
}


//-----------------------------------------------------------------------------
// initialisation
void filterbutterworth::onInitModule (MasterInfo* pMasterInfo, ModuleInfo* pModuleInfo) 
{
	for (int i = 0; i < numOfAudiotInsOuts; i++)
	{

		for (int j = 0; j < 512; j++)
		{
			audioBufferN2[i][j] = 0;
			audioBufferN1[i][j] = 0;
		}
	}
}

//----------------------------------------------------------------------------
// parameters and process
//----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Parameters description
void filterbutterworth::onGetParamInfo (int ParamIndex, TParamInfo* pParamInfo)
{	
    // audioInputs
    if (ParamIndex < numOfAudiotInsOuts)
    {
		pParamInfo->ParamType		= ptAudio;
		pParamInfo->Caption			= sdkGetAudioQueryChannelNames ( "in ", ParamIndex + 1, queryIndex);
		pParamInfo->IsInput			= TRUE;
		pParamInfo->IsOutput		= FALSE;
		pParamInfo->ReadOnly		= FALSE;

        if (ParamIndex == 0)
        {
            pParamInfo->IsSeparator     = TRUE;
            pParamInfo->SeparatorCaption = "audio in";
        }
    }
    // audioOutputs
	else if (ParamIndex >= numOfAudiotInsOuts && ParamIndex < (numOfAudiotInsOuts * 2))
	{
		pParamInfo->ParamType = ptAudio;
		pParamInfo->Caption = sdkGetAudioQueryChannelNames("out ", ParamIndex - numOfAudiotInsOuts + 1, queryIndex);
		pParamInfo->IsInput = FALSE;
		pParamInfo->IsOutput = TRUE;
		pParamInfo->ReadOnly = TRUE;

		if (ParamIndex == numOfAudiotInsOuts)
		{
			pParamInfo->IsSeparator = TRUE;
			pParamInfo->SeparatorCaption = "audio out";
		}
	}

    // filter cutoff
    else if (ParamIndex == numOfAudiotInsOuts*2) {
		pParamInfo->ParamType = ptDataFader;
		pParamInfo->Caption = "cutoff";
		pParamInfo->MinValue = 10;
		pParamInfo->MaxValue = 18000;
		pParamInfo->DefaultValue = 5000;
		pParamInfo->Format = "%.3f";
		pParamInfo->Scale = scLinear;
		pParamInfo->IsInput = TRUE;
		pParamInfo->IsOutput = FALSE;
		pParamInfo->CallBackType = ctImmediate;
    }
	// resonance in dB
	else if (ParamIndex == (1 + (numOfAudiotInsOuts * 2))) {
		pParamInfo->ParamType = ptDataFader;
		pParamInfo->Caption = "resonance";
		pParamInfo->MinValue = 0.1f;
		pParamInfo->MaxValue = 1.414213f;
		pParamInfo->DefaultValue = 0.1f;
		pParamInfo->Format = "%.3f";
		//pParamInfo->Symbol = "coeff";
		pParamInfo->Scale = scLinear;
		pParamInfo->IsInput = TRUE;
		pParamInfo->IsOutput = FALSE;
		pParamInfo->CallBackType = ctImmediate;
	}

}

//-----------------------------------------------------------------------------
// set the parameters events address
void filterbutterworth::onSetEventAddress(int ParamIndex, UsineEventPtr pEvent)
{
	// audioInputs
	if (ParamIndex < numOfAudiotInsOuts)
	{
		audioInputs[ParamIndex] = pEvent;
	}
	// audioOutputs
	else if (ParamIndex >= numOfAudiotInsOuts && ParamIndex < (numOfAudiotInsOuts * 2))
	{
		audioOutputs[ParamIndex - numOfAudiotInsOuts] = pEvent;
	}
	// cutoff
	else if (ParamIndex == numOfAudiotInsOuts*2)
	{
		m_cutoff = pEvent;
	}
	// resonance en dB
	else if (ParamIndex >= (1+numOfAudiotInsOuts*2))
	{
		m_resonance= pEvent;
	}


}

//-----------------------------------------------------------------------------
// Parameters callback
void filterbutterworth::onCallBack(UsineMessage *Message)
{
	// filter only message specific to this user module
	if (Message->message == NOTIFY_MSG_USINE_CALLBACK)
	{
		// Message->wParam is equal to ParamIndex
		if ((Message->wParam == (numOfAudiotInsOuts * 2)) && (Message->lParam == MSG_CHANGE))
		{
				cutoff = sdkGetEvtData(m_cutoff);
				computeCoeff();
		}
		else if ((Message->wParam == (1+numOfAudiotInsOuts * 2)) && (Message->lParam == MSG_CHANGE))
		{
				resonance = sdkGetEvtData(m_resonance);
				computeCoeff();
		}
	}
}

void filterbutterworth::onProcess()
//The filter algo:
//out(n) = a1 * in + a2 * in(n - 1) + a3 * in(n - 2) - b1*out(n - 1) - b2*out(n - 2)
{
	for (int i = 0; i < numOfAudiotInsOuts; i++)
	{
		sdkCopyEvt(audioInputs[i], audioOutputs[i]);
		//filter
		for (int j = 0; j < sdkGetEvtSize(audioOutputs[i]); j++)
		{
			signal =  a1 * sdkGetEvtArrayData(audioInputs[i], j);
			signal += a2 * audioBufferN1[i][j];
			signal += a3 * audioBufferN2[i][j];
			signal -= b1 * audioBufferN1[i][j];
			signal -= b2 * audioBufferN2[i][j];
            //output
			sdkSetEvtArrayData(audioOutputs[i], j, signal);
			audioBufferN2[i][j] =  audioBufferN1[i][j];
			audioBufferN1[i][j] =  signal;
		}
    }
}


void filterbutterworth::computeCoeff() {

	//LP
	c = 1.0f / (tanf(PI * (cutoff / sdkGetSampleRate())));
	csq = c * c;

	a1 = 1.0f / (1.0f + resonance * c + csq);
	a2 = 2 * a1;
	a3 = a1;
	b1 = 2.0f * (1.0f - csq) * a1;
	b2 = (1.0f - resonance * c + csq) * a1;

	
	//sdkTracePrecision(a1);
	sdkTracePrecision(sdkGetSampleRate());


	//HP
/*
	c = tan(PI * cutoff / sdkGetSampleRate());
	a1 = 1.0f / (1.0f + resonance * c + csq);
	a2 = -2 * a1;
	a3 = a1;
	b1 = 2.0f * (csq - 1.0f) * a1;
	b2 = (1.0f - resonance * c + csq) * a1;
	*/
}
