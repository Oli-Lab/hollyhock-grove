//-----------------------------------------------------------------------------
//@file  
//	filter.cpp
//
//@author
//	Martin FLEURENT aka 'martignasse'
//
//@brief 
//	Implementation of the filter class.
//
//  Example user module to show how to process audio buffers.
//
//@historic 
//	2015/02/23
//    first release for Hollyhock CPP SDK 6.04.001
//
//@IMPORTANT
//	This file is part of the Usine Hollyhock CPP SDK
//
//  Please, report bugs and patch to Usine forum :
//  http://www.sensomusic.com/wiki2/doku.php?id=hollyhock:bugsreport 
//
// All dependencies are under there own licence.
//
//@LICENCE
// Copyright (C) 2013, 2014, 2015 Sensomusic
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy of 
// this software and associated documentation files (the "Software"), 
// to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense, 
// and/or sell copies of the Software, and to permit persons to whom the Software 
// is furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in all 
//     copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE 
// SOFTWARE.
//
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// includes
//-----------------------------------------------------------------------------
#include "filter.h"
// module constants for browser info and module info
const AnsiCharPtr UserModuleBase::MODULE_NAME = "Ladder 6db/oct";
const AnsiCharPtr UserModuleBase::MODULE_DESC = "Ladder 6db/oct";
const AnsiCharPtr UserModuleBase::MODULE_VERSION = "0.1";
//----------------------------------------------------------------------------
// create, general info and destroy methodes
//----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Create
void CreateModule(void* &pModule, AnsiCharPtr optionalString, LongBool Flag, MasterInfo* pMasterInfo, AnsiCharPtr optionalContent)
{
	pModule = new filter();
}

// destroy
void DestroyModule(void* pModule)
{
	// cast is important to call the good destructor
	delete ((filter*)pModule);
}

//-------------------------------------------------------------------------
// module constructors/destructors
//-------------------------------------------------------------------------

// constructor
filter::filter()
	: drive(1)//, cutoff(1)
{
	// audio smooth
	m_tevtSmoothCurrentDrive = NULL;
	//m_tevtSmoothCurrentCutoff = NULL;
}

// destructor
filter::~filter()
{
	if (m_tevtSmoothCurrentDrive != NULL)
		sdkDestroyEvt(m_tevtSmoothCurrentDrive);
	//if (m_tevtSmoothCurrentCutoff != NULL)
		//sdkDestroyEvt(m_tevtSmoothCurrentCutoff);
}

// browser info
void GetBrowserInfo(ModuleInfo* pModuleInfo)
{
	pModuleInfo->Name = UserModuleBase::MODULE_NAME;
	pModuleInfo->Description = UserModuleBase::MODULE_DESC;
	pModuleInfo->Version = UserModuleBase::MODULE_VERSION;
}

void filter::onGetModuleInfo(MasterInfo* pMasterInfo, ModuleInfo* pModuleInfo)
{
	pModuleInfo->Name = MODULE_NAME;
	pModuleInfo->Description = MODULE_DESC;
	pModuleInfo->Version = MODULE_VERSION;
	pModuleInfo->ModuleType = mtSimple;
	pModuleInfo->BackColor = sdkGetUsineColor(clAudioModuleColor) + 0x102011;

	// query for multi-channels
	if (pMasterInfo != nullptr)
	{
		pModuleInfo->QueryString = sdkGetAudioQueryTitle();
		pModuleInfo->QueryListValues = sdkGetAudioQueryChannelList();
		pModuleInfo->QueryDefaultIdx = 1;
	}
}

//-----------------------------------------------------------------------------
// query system and init methodes
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// Get total parameters number of the module
int filter::onGetNumberOfParams(int queryIndex)
{
	int result = 0;
	this->queryIndex = queryIndex;
	numOfAudiotInsOuts = sdkGetAudioQueryToNbChannels(queryIndex);

	// we want 1 in 1 out per channels
	result = (numOfAudiotInsOuts * 2) + numOfParamAfterAudiotInOut;

	return result;
}

//-----------------------------------------------------------------------------
// Called after the query popup
void filter::onAfterQuery(MasterInfo* pMasterInfo, ModuleInfo* pModuleInfo, int queryIndex)
{
	sdkCreateEvt(m_tevtSmoothCurrentDrive, pMasterInfo->BlocSize);
	//sdkCreateEvt(m_tevtSmoothCurrentCutoff, pMasterInfo->BlocSize);
}


//-----------------------------------------------------------------------------
// initialisation
void filter::onInitModule(MasterInfo* pMasterInfo, ModuleInfo* pModuleInfo)
{
	for (int i = 0; i < numOfAudiotInsOuts; i++)
	{

		audioBufferOldX[i] = 0;
		audioBufferOldY1[i] = 0;
		inv_samplerate = 1 / sdkGetSampleRate();
		resonanceRaw = 0;
		driveRaw = 0;
	}
	POLE[0] = 0;
	//POLE[1] = 0;
	//POLE[2] = 0;
	//POLE[3] = 0;
}

//----------------------------------------------------------------------------
// parameters and process
//----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Parameters description
void filter::onGetParamInfo(int ParamIndex, TParamInfo* pParamInfo)
{
	// audioInputs
	if (ParamIndex < numOfAudiotInsOuts)
	{
		pParamInfo->ParamType = ptAudio;
		pParamInfo->Caption = sdkGetAudioQueryChannelNames("in ", ParamIndex + 1, queryIndex);
		pParamInfo->IsInput = TRUE;
		pParamInfo->IsOutput = FALSE;
		pParamInfo->ReadOnly = FALSE;

		if (ParamIndex == 0)
		{
			pParamInfo->IsSeparator = TRUE;
			pParamInfo->SeparatorCaption = "audio in";
		}
	}
	// audioOutputs
	else if (ParamIndex >= numOfAudiotInsOuts && ParamIndex < (numOfAudiotInsOuts * 2))
	{
		pParamInfo->ParamType = ptAudio;
		pParamInfo->Caption = sdkGetAudioQueryChannelNames("out ", ParamIndex - numOfAudiotInsOuts + 1, queryIndex);
		pParamInfo->IsInput = FALSE;
		pParamInfo->IsOutput = TRUE;
		pParamInfo->ReadOnly = TRUE;

		if (ParamIndex == numOfAudiotInsOuts)
		{
			pParamInfo->IsSeparator = TRUE;
			pParamInfo->SeparatorCaption = "audio out";
		}
	}

	// filter cutoff
	else if (ParamIndex == numOfAudiotInsOuts * 2) {
		pParamInfo->ParamType = ptDataFader;
		pParamInfo->Caption = "cutoff";
		pParamInfo->MinValue = 10.0f;
		pParamInfo->MaxValue = 20000.0f;
		pParamInfo->DefaultValue = 20000.0f;
		pParamInfo->Format = "%.3f";
		pParamInfo->Scale = scLog;
		pParamInfo->IsInput = TRUE;
		pParamInfo->IsOutput = FALSE;
		pParamInfo->CallBackType = ctImmediate;
	}
	// resonance
	else if (ParamIndex == (1 + (numOfAudiotInsOuts * 2))) {
		pParamInfo->ParamType = ptDataFader;
		pParamInfo->Caption = "resonance";
		pParamInfo->MinValue = 0.0f;
		pParamInfo->MaxValue = 1.0f;
		pParamInfo->DefaultValue = 0.0f;
		pParamInfo->Format = "%.3f";
		//pParamInfo->Symbol = "coeff";
		pParamInfo->Scale = scLinear;
		pParamInfo->IsInput = TRUE;
		pParamInfo->IsOutput = FALSE;
		pParamInfo->CallBackType = ctImmediate;
	}

	else if (ParamIndex == (2 + (numOfAudiotInsOuts * 2))) {
		pParamInfo->ParamType = ptDataFader;
		pParamInfo->Caption = "drive";
		pParamInfo->MinValue = 0.0f;
		pParamInfo->MaxValue = 1.0f;
		pParamInfo->DefaultValue = 0.0f;
		pParamInfo->Format = "%.3f";
		pParamInfo->Scale = scLog;
		pParamInfo->IsInput = TRUE;
		pParamInfo->IsOutput = FALSE;
		pParamInfo->CallBackType = ctImmediate;
	}

	//pr�voir entr�e audio pour filter FM
	else if (ParamIndex == (3 + (numOfAudiotInsOuts * 2))) {
		pParamInfo->ParamType = ptAudio;
		pParamInfo->Caption = "FM in";
		pParamInfo->IsInput = TRUE;
		pParamInfo->IsOutput = FALSE;
		pParamInfo->ReadOnly = FALSE;
	}
	//prevoir entr�e 0-1 pour Filter FM amount (growl)
	else if (ParamIndex == (4 + (numOfAudiotInsOuts * 2))) {
		pParamInfo->ParamType = ptDataFader;
		pParamInfo->Caption = "FM amount";
		pParamInfo->MinValue = 0.0f;
		pParamInfo->MaxValue = 1.0f;
		pParamInfo->DefaultValue = 0.0f;
		pParamInfo->Format = "%.3f";
		pParamInfo->Scale = scLinear;
		pParamInfo->IsInput = TRUE;
		pParamInfo->IsOutput = FALSE;
		pParamInfo->CallBackType = ctImmediate;
	}

	else if (ParamIndex == (5 + (numOfAudiotInsOuts * 2))) {
		pParamInfo->ParamType = ptListBox;
		pParamInfo->Caption = "F type";
		pParamInfo->ListBoxStrings = "\"Lo Pass\",\"Hi Pass\",\"Band Pass\",\"Notch\"";
		pParamInfo->DefaultValue = 0;
		pParamInfo->IsInput = TRUE;
		pParamInfo->IsOutput = FALSE;
		//pParamInfo->CallBackType = ctImmediate;
	}

}

//-----------------------------------------------------------------------------
// set the parameters events address
void filter::onSetEventAddress(int ParamIndex, UsineEventPtr pEvent)
{
	// audioInputs
	if (ParamIndex < numOfAudiotInsOuts)
	{
		audioInputs[ParamIndex] = pEvent;
	}
	// audioOutputs
	else if (ParamIndex >= numOfAudiotInsOuts && ParamIndex < (numOfAudiotInsOuts * 2))
	{
		audioOutputs[ParamIndex - numOfAudiotInsOuts] = pEvent;
	}
	// cutoff
	else if (ParamIndex == numOfAudiotInsOuts * 2)
	{
		m_cutoff = pEvent;
	}
	// resonance
	else if (ParamIndex == (1 + numOfAudiotInsOuts * 2))
	{
		m_resonance = pEvent;
	}
	else if (ParamIndex == (2 + numOfAudiotInsOuts * 2))
	{
		m_drive = pEvent;
	}
	else if (ParamIndex == (3 + numOfAudiotInsOuts * 2))
	{
		audioFMinput = pEvent;
	}
	else if (ParamIndex == (4 + numOfAudiotInsOuts * 2))
	{
		m_growl = pEvent;
	}
	else if (ParamIndex == (5 + numOfAudiotInsOuts * 2))
	{
		m_type = pEvent;
	}

}

//-----------------------------------------------------------------------------
// Parameters callback
void filter::onCallBack(UsineMessage *Message)
{
	// filter only message specific to this user module
	if (Message->message == NOTIFY_MSG_USINE_CALLBACK)
	{
		// Message->wParam is equal to ParamIndex
		if ((Message->wParam == (numOfAudiotInsOuts * 2)) && (Message->lParam == MSG_CHANGE))
		{
			cutoff = sdkGetEvtData(m_cutoff);
		}
		else if ((Message->wParam == (1 + numOfAudiotInsOuts * 2)) && (Message->lParam == MSG_CHANGE))
		{
			resonanceRaw = sdkGetEvtData(m_resonance);
		}
		else if ((Message->wParam == (2 + numOfAudiotInsOuts * 2)) && (Message->lParam == MSG_CHANGE))
		{
			driveRaw = sdkGetEvtData(m_drive); //drive = (sdkGetEvtData(m_drive)*5)+1;
		}
		else if ((Message->wParam == (4 + numOfAudiotInsOuts * 2)) && (Message->lParam == MSG_CHANGE))
		{
			growlRaw = sdkGetEvtData(m_growl);
			growl = 5000.0f * powf(growlRaw, 2);
		}
		else if ((Message->wParam == (5 + numOfAudiotInsOuts * 2)) && (Message->lParam == MSG_CHANGE))
		{
			type = sdkGetEvtData(m_type);
			//sdkTraceInt(type);
		}

	}
}

void filter::onProcess() {
	//sdkSmoothEvent(m_smoothOldCutoff, m_tevtSmoothCurrentCutoff, cutoff, 0.1f);
	sdkSmoothPrecision(cutoff, m_cutoff, 0.1f);
	drive = driveRaw + 1.0f;
	sdkSmoothEvent(m_smoothOldDrive, m_tevtSmoothCurrentDrive, drive, 0.999f);

	if (growlRaw <= 0.000001f) {
		cutoffFinal = 20000.0f - cutoff;
		computeCoeff();
	}
	else {}

	for (int i = 0; i < numOfAudiotInsOuts; i++)
	{
		sdkCopyEvt(audioInputs[i], audioOutputs[i]);
		sdkMultEvt2Audio(m_tevtSmoothCurrentDrive, audioInputs[i]);
		//filter

		for (int j = 0; j < sdkGetEvtSize(audioOutputs[i]); j++)
		{
			if (growlRaw > 0.000001f) {
				cutoffFinal = 20000.0f - cutoff + growl * sdkGetEvtArrayData(audioFMinput, j) * cutoff / 10000.0f;
				if (cutoffFinal < 10.0f) {
					cutoffFinal = 10.0f;
				}
				else if (cutoffFinal > 20000.0f) {
					cutoffFinal = 20000.0f;
				}
				else {}
				computeCoeff();
			}
			else {}
			/*
			// algorithm
			//--Inverted feed back for corner peaking
x = input - r*y4;

//Four cascaded onepole filters (bilinear transform)
y1=x*p + oldx*p - k*y1;
y2=y1*p+oldy1*p - k*y2;
y3=y2*p+oldy2*p - k*y3;
y4=y3*p+oldy3*p - k*y4;
// Lowpass  output:  y4
// Highpass output:  in - y4;
//Clipper band limited sigmoid
y4 = y4 - (y4^3)/6;
oldx = x;
oldy1 = y1;
oldy2 = y2;
oldy3 = y3;
			*/
			int b_oversample = 0;
			float b_inSH = sdkGetEvtArrayData(audioInputs[i], j); // before the while statement.
			while (b_oversample < 2) { 
			//2x oversampling
			signal = b_inSH - resonance * audioBufferOldY4[i]; //what goes in the filter
			POLE[0] = (signal + audioBufferOldX[i])*p;
			POLE[0] *= (1 - k);
			POLE[1] = (POLE[0] + audioBufferOldY1[i])*p;
			POLE[1] *= (1 - k);
			POLE[2] = (POLE[1] + audioBufferOldY2[i])*p;
			POLE[2] *= (1 - k);
			POLE[3] = (POLE[2] + audioBufferOldY3[i])*p;
			POLE[3] *= (1 - k);


			//Clipper band limited sigmoid
			POLE[3] = POLE[3] - (POLE[3]* POLE[3]* POLE[3]) / 6;
			
			//
			audioBufferOldX[i] = signal;
			audioBufferOldY1[i] = POLE[0];
			audioBufferOldY2[i] = POLE[1];
			audioBufferOldY3[i] = POLE[2];
			audioBufferOldY4[i] = POLE[3];
			
			b_oversample++;
			}
			float out = POLE[0] / (1 + abs(POLE[0]));//soft clipping
			sdkSetEvtArrayData(audioOutputs[i], j, out);
		}
	}
}


void filter::computeCoeff() {
	f = 2 * cutoffFinal * inv_samplerate;
	k = 3.6*f - 1.6*f*f - 1; //(Empirical tunning)
	p = (k + 1)*0.5;
	scale = exp2f((1 - p)*1.386249);
	resonance = resonanceRaw*scale;
}

/*
float filter::map(float x, float in_min, float in_max, float out_min, float out_max)
{
return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}
*/